﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace DongHoShop.Models
{
    public class LoaiSanPham
    {

        [DisplayName("Mã Loại")]
        public int ID { get; set; }
        [Display(Name = "Tên Loại")]
        [StringLength(255)]
        [Required(ErrorMessage = "Tên loại không được bỏ trống!")]
        public string TenLoai { get; set; }
        public ICollection<SanPham>? SanPham { get; set; }
    }
}
