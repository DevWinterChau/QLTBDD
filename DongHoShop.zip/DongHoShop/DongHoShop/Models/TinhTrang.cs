﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace DongHoShop.Models
{
    public class TinhTrang
    {

        public int ID { get; set; }
        [StringLength(255)]
        [Required(ErrorMessage = "không được bỏ trống!")]
        [DisplayName("Mô tả")]
        public string MoTa { get; set; }
        public ICollection<DatHang>? DatHang { get; set; }

    }
}
