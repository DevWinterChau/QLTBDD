﻿using DongHoShop.Models;
namespace DongHoShop.Logic
{
    public interface IMailLogic
    {
        Task SendEmail(MailInfo mailInfo);
        Task SendEmailDatHangThanhCong(DatHang datHang, MailInfo mailInfo);
    }
}